#!/usr/bin/env bash
set -euo pipefail

APP_ID="com.example.earthexplorer"
APK="app/build/outputs/apk/debug/app-debug.apk"
AAB="app/build/outputs/bundle/release/app-release.aab"
BUILD_TOOLS_VERSION="36.0.0"
ANDROID_SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"

for file in "$APK" "$AAB"; do
  if [[ ! -s "$file" ]]; then
    echo "ERROR: build output missing or empty: $file" >&2
    exit 1
  fi
done

if [[ -z "$ANDROID_SDK_ROOT" ]]; then
  echo "ERROR: ANDROID_HOME/ANDROID_SDK_ROOT is not set" >&2
  exit 1
fi

AAPT="$ANDROID_SDK_ROOT/build-tools/$BUILD_TOOLS_VERSION/aapt"
APKSIGNER="$ANDROID_SDK_ROOT/build-tools/$BUILD_TOOLS_VERSION/apksigner"
for tool in "$AAPT" "$APKSIGNER"; do
  if [[ ! -x "$tool" ]]; then
    echo "ERROR: Android build tool not found: $tool" >&2
    exit 1
  fi
done

BADGING="$("$AAPT" dump badging "$APK")"
grep -F "package: name='$APP_ID'" <<<"$BADGING" >/dev/null || {
  echo "ERROR: unexpected APK applicationId" >&2
  exit 1
}

VERSION_NAME="$(sed -n 's/^[[:space:]]*versionName = "\([^"]*\)".*/\1/p' app/build.gradle.kts | head -n1)"
VERSION_CODE="$(sed -n 's/^[[:space:]]*versionCode = \([0-9][0-9]*\).*/\1/p' app/build.gradle.kts | head -n1)"
[[ -n "$VERSION_NAME" && -n "$VERSION_CODE" ]] || {
  echo "ERROR: could not read versionName/versionCode" >&2
  exit 1
}
grep -F "versionName='$VERSION_NAME'" <<<"$BADGING" >/dev/null || {
  echo "ERROR: APK versionName does not match Gradle configuration" >&2
  exit 1
}
grep -F "versionCode='$VERSION_CODE'" <<<"$BADGING" >/dev/null || {
  echo "ERROR: APK versionCode does not match Gradle configuration" >&2
  exit 1
}

# A debug APK must be signed and verifiable before it is offered for device installation.
"$APKSIGNER" verify --verbose "$APK"

mkdir -p build-delivery
cp "$APK" build-delivery/
cp "$AAB" build-delivery/
cat > build-delivery/BUILD_INFO.txt <<INFO
applicationId=$APP_ID
versionName=$VERSION_NAME
versionCode=$VERSION_CODE
gitCommit=${GITHUB_SHA:-local}
githubRun=${GITHUB_RUN_NUMBER:-local}
apkSignature=verified-debug-signature
aabSigning=unsigned-unless-release-keystore-configured
INFO
(
  cd build-delivery
  sha256sum app-debug.apk app-release.aab > SHA256SUMS.txt
)
echo "Verified APK and AAB for $APP_ID $VERSION_NAME ($VERSION_CODE)."
