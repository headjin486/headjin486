#!/usr/bin/env bash
set -euo pipefail
SERVICE="app/src/main/java/com/example/earthexplorer/LocationTrackingService.kt"
BUILD="app/build.gradle.kts"

# A failed foreground-service promotion must never be restarted as a sticky tracker.
grep -F 'if (stopping.get() && intent?.action != ACTION_STOP) return START_NOT_STICKY' "$SERVICE" >/dev/null
# Explicit user stop must remove location callbacks and stop the foreground service.
grep -F 'fused.removeLocationUpdates(callback)' "$SERVICE" >/dev/null
grep -F 'stopForeground(STOP_FOREGROUND_REMOVE)' "$SERVICE" >/dev/null
# Accepted DB writes must drain before the DB close task.
grep -F 'persistenceExecutor.execute { store.close() }' "$SERVICE" >/dev/null
grep -F 'persistenceExecutor.shutdown()' "$SERVICE" >/dev/null
# Release candidate identifiers must be incremented together.
grep -F 'versionCode = 28' "$BUILD" >/dev/null
grep -F 'versionName = "0.7.4"' "$BUILD" >/dev/null
printf 'Service lifecycle static checks: 7/7 passed.\n'
