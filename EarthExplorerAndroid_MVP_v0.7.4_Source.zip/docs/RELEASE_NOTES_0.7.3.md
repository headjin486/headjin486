# v0.7.3

- Android 원격 빌드 산출물 검증 스크립트 추가.
- APK 패키지명·versionName·versionCode 대조 및 debug 서명 검증 후에만 배포 아티팩트 생성.
- 빌드 산출물 SHA-256 체크섬과 빌드 메타데이터 기록.
- GitHub Actions에서 APK/AAB 받는 절차와 출시 전 필수 작업을 한국어 문서화.
- Android 앱 버전: 0.7.3 (versionCode 27).

이 버전은 Android SDK/Gradle 환경에서 실제 빌드되지 않았으며, CI 실행 결과도 아직 없습니다.
