# EARTH UNLOCK 0.6.8

- 앱 버전 `0.6.8` (`versionCode 22`).
- Android CI가 APK와 AAB 파일이 실제로 생성됐는지 확인한 뒤에만 아티팩트를 업로드하도록 강화했습니다.
- 빌드 산출물에 SHA-256 체크섬과 버전 정보를 함께 포함합니다.
- GitHub Actions 아티팩트 보존 기간을 30일로 명시했습니다.

## 검증 상태

- 워크플로 YAML 및 빌드 산출물 검증 단계 정적 검사: 통과.
- 이 작업 환경에는 Android SDK/Gradle 실행 환경과 프로젝트 원격 저장소 인증이 없어 실제 Android 빌드 및 GitHub Actions 실행은 하지 못했습니다.
- APK/AAB 생성 및 실기기 설치는 아직 검증되지 않았습니다.
