# v0.7.4

- LocationTrackingService가 onCreate에서 위치 포그라운드 서비스로 승격되지 못해 stopping 상태가 된 경우, onStartCommand에서 START_NOT_STICKY를 반환합니다. 권한 철회 또는 OS의 FGS 시작 제한 때문에 실패한 서비스가 sticky 재생성 루프에 들어가는 것을 방지합니다.
- 서비스 시작 실패, 사용자 중지, 저장 작업 drain 후 DB 종료 순서를 확인하는 정적 검사 스크립트를 추가했습니다.
- GitHub Actions에서 서비스 수명주기 정적 검사를 Android 빌드 전에 실행합니다.
- Android versionName 0.7.4 / versionCode 28.

실제 Android SDK/Gradle 빌드, GitHub Actions 실행 및 갤럭시 실기기 검증은 아직 수행하지 않았습니다.
