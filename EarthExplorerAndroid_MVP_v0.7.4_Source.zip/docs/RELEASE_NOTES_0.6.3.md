# 0.6.3 변경 사항

- GPS 위치 기록, 거리 누적값 갱신, 주변 탐험 격자 공개를 하나의 SQLite 트랜잭션으로 묶었습니다. 오류가 발생하면 세 변경 사항이 함께 롤백됩니다.
- 서비스는 이전에 저장한 위치보다 timestamp가 오래되었거나 같은 GPS fix를 무시합니다. 0 이하 timestamp도 수집하지 않습니다.
- 주변 격자 삽입에 단일 컴파일 SQLite statement를 재사용해 셀마다 SQL 컴파일을 반복하지 않도록 했습니다.
- 새 단위 테스트: 최신 GPS timestamp 판별.
- 앱 버전: `0.6.3` (`versionCode 17`).

## 검증 상태

- 소스 정적 점검 8개 항목 통과.
- 순수 Kotlin 계산 스모크 테스트 8개 통과.
- Android Gradle 빌드, APK 설치, 실제 GPS 이동 테스트: 이 작업 환경에서 Android SDK/Gradle/실기기 접근이 없어 수행하지 못했습니다.
