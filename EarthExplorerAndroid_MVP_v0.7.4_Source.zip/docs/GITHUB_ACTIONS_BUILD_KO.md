# Android 원격 빌드 및 APK 받기

현재 개발 실행 환경에는 Android SDK와 Gradle이 없어 여기서 APK를 직접 만들 수 없습니다. 이 프로젝트에는 GitHub Actions 원격 빌드가 포함되어 있습니다.

## 최초 1회 설정

1. GitHub 계정으로 로그인하고 새 저장소(repository)를 만듭니다. 저장소 이름 예: `earth-unlock-android`.
2. 이 ZIP의 압축을 풉니다. `earthunlock_067` 폴더 안의 **파일과 폴더 전체**를 저장소 최상위에 올립니다. `.github` 폴더도 반드시 포함해야 합니다.
3. GitHub 저장소의 **Actions** 탭을 열고 워크플로 실행을 허용합니다.
4. **Actions → Android build and tests → Run workflow**를 선택합니다. 이후 소스를 저장소에 push할 때도 자동 실행됩니다.

## APK 받기

1. Actions 탭에서 가장 최근 실행을 엽니다.
2. 실행 상태가 초록색 성공(✓)인지 확인합니다.
3. 실행 페이지 아래 **Artifacts**에서 `earth-unlock-android-builds-실행번호`를 다운로드합니다.
4. 압축을 풀고 `app-debug.apk`를 Android 휴대전화로 옮겨 설치합니다. `SHA256SUMS.txt`는 파일 무결성 확인용입니다.

## 파일의 의미

- `app-debug.apk`: 기기 설치·기능 확인용 APK이며 Android 디버그 키로 서명됩니다.
- `app-release.aab`: Play Console 업로드용 빌드 산출물입니다. 개인 릴리스 키가 설정되지 않았다면 서명되지 않으므로 그대로 출시할 수 없습니다.
- APK는 CI에서 패키지명, 버전, 서명 유효성을 확인한 뒤에만 Artifact로 업로드됩니다.

## 아직 남은 출시 작업

- 현재 `applicationId`는 `com.example.earthexplorer` 임시값입니다. 공개 출시 전 고유한 패키지명으로 확정해야 합니다.
- Play App Signing/업로드 키를 별도로 생성하고 안전하게 보관해야 합니다. 개인 키 파일과 비밀번호를 채팅이나 공개 저장소에 올리면 안 됩니다.
- 실제 갤럭시 기기에서 GPS, 화면 잠금, 백그라운드 추적, 권한 철회, 배터리 소모를 확인해야 합니다.
- Play Console의 개인정보 처리방침, Data safety, 위치 권한 선언, 스토어 등록 자료를 완료해야 합니다.

**주의:** GitHub Actions가 성공하기 전에는 설치 APK가 생성된 것이 아닙니다. 소스 ZIP 자체는 설치파일이 아닙니다.
