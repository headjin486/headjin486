# 0.6.4 변경 사항

- `app_stats.explored_area_m2`에 누적 공개 면적을 저장합니다. 이후 지도 갱신 시 전체 `explored_cells`를 GROUP BY로 훑지 않고 단일 통계 행에서 읽습니다.
- 기존 설치 데이터는 면적 통계를 처음 요청할 때 한 번 계산하고, 이후 새로 삽입된 격자만 위도 보정 면적을 더합니다.
- `INSERT OR IGNORE` 결과가 신규 rowid인지 확인해 이미 공개된 셀은 면적에 중복 합산하지 않습니다.
- SQLite DB 스키마 버전을 4에서 5로 올리고, 기존 `app_stats` 테이블에 `explored_area_m2`를 추가하는 마이그레이션을 구현했습니다.
- 앱 버전: `0.6.4` (`versionCode 18`).

## 검증 상태

- `TrackMathTest` 14개 테스트 실행 통과(로컬 경량 테스트 러너).
- `TrackStore.kt` + `TrackMath.kt` Kotlin 구문/API 형태 컴파일 통과(최소 Android SQLite 스텁 사용; 실제 Android SDK 컴파일은 아님).
- SQLite v4→v5 마이그레이션 및 중복 셀 면적 재합산 방지 시뮬레이션 통과.
- Android XML 파싱 및 소스 ZIP 무결성 검사 통과.
- 실제 Android Gradle 빌드, APK 설치, 실기기 GPS 테스트는 아직 수행하지 않았습니다.
