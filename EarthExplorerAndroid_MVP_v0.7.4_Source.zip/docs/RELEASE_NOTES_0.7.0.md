# v0.7.0

- Added an atomic shutdown gate to the location tracking service.
- Late fused-location callbacks are ignored once service shutdown begins.
- Queued SQLite writes accepted before shutdown are drained before the database is closed.
- Increased Android versionCode to 24 and versionName to 0.7.0.

## Verification status

- Source-level lifecycle checks: passed.
- Android Gradle build: not run in this environment (Android SDK/Gradle unavailable).
- Emulator and physical-device location tests: not run.
