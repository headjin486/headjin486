# 0.5.6 변경 기록

- Release 빌드용 로컬 keystore.properties 기반 서명 설정 추가.
- 서명 키/비밀번호는 프로젝트 ZIP에 포함하지 않으며 .gitignore 처리.
- Release minify는 테스트 전 비활성화.
- versionCode 10 / versionName 0.5.6.

서명 키 생성, 실제 Release AAB 빌드 및 Play Console 업로드는 아직 수행되지 않았습니다.
