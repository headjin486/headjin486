# EARTH UNLOCK v0.7.2

## 변경 사항
- Android의 위치 포그라운드 서비스 시작이 권한 또는 시스템 제한으로 거부되면 서비스를 중지해 알림 없는 위치 추적이 남지 않도록 처리했습니다.
- Fused Location Provider가 권한 철회/제공자 오류를 비동기 Task 실패로 보고하는 경우를 처리합니다.
- 종료 과정에서 저장 Executor가 이미 종료된 예외 상황에 대한 DB close 방어 처리를 추가했습니다.

## 검증 범위
- 소스 정적 검사: 수행
- 순수 Kotlin 계산 테스트: 기존 스모크 테스트 재실행
- Android Gradle 빌드: 미실행 (이 환경에 Android SDK/Gradle 없음)
- 실기기 백그라운드/화면 잠금/권한 철회 테스트: 미실행
