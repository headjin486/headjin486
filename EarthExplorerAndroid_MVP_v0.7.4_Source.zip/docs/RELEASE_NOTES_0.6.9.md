# EARTH UNLOCK 0.6.9

- 앱 버전 `0.6.9` (`versionCode 23`).
- Activity 종료 시 지도 조회 executor가 SQLite 조회를 마친 뒤 데이터베이스 helper를 닫도록 변경했습니다.
- 종료 시점에 남은 오래된 지도 갱신 결과는 generation 검사에서 폐기합니다.

## 검증 상태

- 소스 변경 및 버전 정보 정적 검사: 수행 예정.
- 실제 Android 빌드, 에뮬레이터 실행, 실기기 설치 및 GPS 백그라운드 테스트: 아직 수행되지 않았습니다.
