# 0.5.7 변경 기록

- 앱 시작 시 마지막 GPS 위치만 조회하고 전체 GPS 이력 로딩 제거.
- 지도 화면 GPS 기록 수는 SQLite COUNT(*)로 계산.
- Fog Overlay 셀 목록이 동일하면 비트맵 캐시 유지.
- TrackMath 순수 계산 모듈 및 단위 테스트 7개 추가.
- GitHub Actions에서 Android API 36 테스트, Debug APK 및 Release AAB 자동 빌드.
- versionCode 11 / versionName 0.5.7.

Android SDK와 Gradle이 없는 현재 실행 환경에서는 Android Gradle 빌드를 실행하지 못했습니다. CI 워크플로는 저장소에 push한 뒤 실행 결과로 검증해야 합니다.
