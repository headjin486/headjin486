# EARTH UNLOCK 0.7.1

## 변경 사항
- Activity 종료와 지도 이벤트가 경합할 때 종료된 조회 Executor에 작업을 제출하는 예외를 처리합니다.
- 종료 플래그를 먼저 설정해 신규 지도 조회 및 늦은 UI 반영을 막습니다.
- Activity 소유 SQLite 연결은 진행 중인 조회가 끝난 뒤 닫습니다.
- 위치 서비스의 SQLite 종료 작업은 접수된 GPS 저장 작업 뒤에 직렬 실행되도록 유지합니다.
- 앱 버전: 0.7.1 / versionCode 25.

## 검증 범위
- 소스 정적 검사 및 순수 Kotlin 계산 테스트 수행.
- Android Gradle 빌드, APK/AAB 생성, 에뮬레이터 및 실기기 테스트는 미수행.
