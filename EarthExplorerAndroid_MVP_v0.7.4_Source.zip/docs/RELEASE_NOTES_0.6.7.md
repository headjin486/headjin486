# EARTH UNLOCK 0.6.7

## 수정 사항
- FogOverlay의 경도 좌표 변환을 TrackStore의 equirectangular X 좌표 생성식과 일치시켰습니다.
- 기존 0.6.6의 `1/cos(latitude)` 보정은 저장 좌표에 중복 적용되어 중위도에서 격자 경도를 잘못 이동시킬 수 있었습니다.
- 구미 경도 좌표 왕복 및 중위도 좌표 변환 회귀 테스트를 추가했습니다.

## 검증 상태
- 순수 Kotlin 회귀 테스트: 별도 kotlinc 스모크 테스트 수행 예정
- Android Gradle 빌드: 미실시 (현재 실행 환경에 Gradle 및 Android SDK 없음)
- APK/AAB 및 실기기 설치: 미실시
