package com.example.earthexplorer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TrackMathTest {
    @Test fun identicalCoordinatesHaveZeroDistance() {
        assertEquals(0.0, TrackMath.haversineMeters(37.0, 127.0, 37.0, 127.0), 0.001)
    }

    @Test fun oneDegreeAtEquatorIsApproximately111Kilometers() {
        val distance = TrackMath.haversineMeters(0.0, 0.0, 0.0, 1.0)
        assertEquals(111_195.0, distance, 150.0)
    }

    @Test fun datelineCrossingUsesShortArc() {
        val distance = TrackMath.haversineMeters(0.0, 179.9, 0.0, -179.9)
        assertTrue("Expected a short dateline crossing, got $distance", distance < 23_000.0)
    }

    @Test fun plausibleSegmentIsCounted() {
        val a = TrackPoint(37.0, 127.0, 5f, 1_000L)
        val b = TrackPoint(37.0001, 127.0, 5f, 11_000L)
        assertTrue(TrackMath.validSegmentDistanceMeters(a, b) > 5.0)
    }

    @Test fun longGapIsNotCounted() {
        val a = TrackPoint(37.0, 127.0, 5f, 1_000L)
        val b = TrackPoint(37.001, 127.0, 5f, 200_000L)
        assertEquals(0.0, TrackMath.validSegmentDistanceMeters(a, b), 0.0)
    }

    @Test fun teleportOrImpossibleSpeedIsNotCounted() {
        val a = TrackPoint(37.0, 127.0, 5f, 1_000L)
        val b = TrackPoint(37.1, 127.0, 5f, 2_000L)
        assertEquals(0.0, TrackMath.validSegmentDistanceMeters(a, b), 0.0)
    }

    @Test fun fogAggregationGetsCoarserAsZoomDecreases() {
        assertEquals(1, TrackMath.fogAggregationFactor(18.0))
        assertEquals(4, TrackMath.fogAggregationFactor(17.0))
        assertEquals(64, TrackMath.fogAggregationFactor(13.0))
        assertEquals(65_536, TrackMath.fogAggregationFactor(3.0))
    }

    @Test fun fogAggregationCanIncreaseToAvoidViewportTruncation() {
        assertEquals(2, TrackMath.nextFogAggregationFactor(1))
        assertEquals(128, TrackMath.nextFogAggregationFactor(64))
    }

    @Test fun fogAggregationNeverExceedsMaximumFactor() {
        assertEquals(TrackMath.MAX_FOG_AGGREGATION_FACTOR,
            TrackMath.nextFogAggregationFactor(TrackMath.MAX_FOG_AGGREGATION_FACTOR))
        assertEquals(TrackMath.MAX_FOG_AGGREGATION_FACTOR,
            TrackMath.nextFogAggregationFactor(Int.MAX_VALUE))
    }

    @Test fun gridLongitudeConversionInvertsTrackStoreEquirectangularX() {
        val longitude = 127.8
        val cellX = TrackMath.EARTH_RADIUS_METERS * Math.toRadians(longitude) / 5.0
        assertEquals(longitude, TrackMath.gridLongitudeDegrees(cellX, 5.0), 0.000001)
    }

    @Test fun gridLongitudeConversionDoesNotShiftCoordinatesAtMidLatitudes() {
        val cellX = 4_000_000.0
        val expected = Math.toDegrees(cellX * 5.0 / TrackMath.EARTH_RADIUS_METERS)
        assertEquals(expected, TrackMath.gridLongitudeDegrees(cellX, 5.0), 0.000001)
    }

    @Test fun gridLatitudeConversionRoundTripsExpectedLatitude() {
        val y = TrackMath.EARTH_RADIUS_METERS * Math.toRadians(36.5) / 5.0
        assertEquals(36.5, TrackMath.gridLatitudeDegrees(y, 5.0), 0.000001)
    }

    @Test fun exploredCellAreaIsTwentyFiveSquareMetersAtEquator() {
        assertEquals(25.0, TrackMath.exploredCellAreaSquareMeters(0, 5.0), 0.0001)
    }

    @Test fun exploredCellAreaShrinksWithLatitude() {
        val cellY = (TrackMath.EARTH_RADIUS_METERS * Math.toRadians(60.0) / 5.0).toInt()
        val area = TrackMath.exploredCellAreaSquareMeters(cellY, 5.0)
        assertEquals(12.5, area, 0.02)
    }

    @Test fun exploredCellAreaAtGumiLatitudeIsApproximatelyTwentySquareMeters() {
        val cellY = (TrackMath.EARTH_RADIUS_METERS * Math.toRadians(36.5) / 5.0).toInt()
        val area = TrackMath.exploredCellAreaSquareMeters(cellY, 5.0)
        assertEquals(20.1, area, 0.1)
    }

    @Test fun outOfOrderFixIsNotCounted() {
        val a = TrackPoint(37.0, 127.0, 5f, 10_000L)
        val b = TrackPoint(37.0001, 127.0, 5f, 9_000L)
        assertEquals(0.0, TrackMath.validSegmentDistanceMeters(a, b), 0.0)
    }
    @Test fun newerFixMustHaveStrictlyLaterPositiveTimestamp() {
        assertTrue(TrackMath.isNewerFix(10_000L, 10_001L))
        assertTrue(!TrackMath.isNewerFix(10_000L, 10_000L))
        assertTrue(!TrackMath.isNewerFix(10_000L, 9_999L))
        assertTrue(!TrackMath.isNewerFix(0L, 0L))
    }

    @Test fun validGpsFixAcceptsNormalCoordinatesAndAccuracy() {
        assertTrue(TrackMath.isValidFix(36.5, 127.8, 8f, 1_700_000_000_000L))
    }

    @Test fun invalidGpsFixRejectsOutOfRangeCoordinates() {
        assertTrue(!TrackMath.isValidFix(91.0, 127.8, 8f, 1_700_000_000_000L))
        assertTrue(!TrackMath.isValidFix(36.5, 181.0, 8f, 1_700_000_000_000L))
    }

    @Test fun invalidGpsFixRejectsNanAndInfiniteValues() {
        assertTrue(!TrackMath.isValidFix(Double.NaN, 127.8, 8f, 1_700_000_000_000L))
        assertTrue(!TrackMath.isValidFix(36.5, Double.POSITIVE_INFINITY, 8f, 1_700_000_000_000L))
        assertTrue(!TrackMath.isValidFix(36.5, 127.8, Float.NaN, 1_700_000_000_000L))
    }

    @Test fun invalidGpsFixRejectsWeakAccuracyAndMissingTimestamp() {
        assertTrue(!TrackMath.isValidFix(36.5, 127.8, 20.1f, 1_700_000_000_000L))
        assertTrue(!TrackMath.isValidFix(36.5, 127.8, -1f, 1_700_000_000_000L))
        assertTrue(!TrackMath.isValidFix(36.5, 127.8, 8f, 0L))
    }

}
