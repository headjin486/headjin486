package com.example.earthexplorer

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.database.sqlite.SQLiteStatement
import kotlin.math.*

data class TrackPoint(val lat: Double, val lon: Double, val accuracy: Float, val time: Long)
data class ExploredCell(val x: Double, val y: Double, val scale: Int = 1)

class TrackStore(context: Context) : SQLiteOpenHelper(context, "earth_explorer.db", null, 5) {
    companion object { const val CELL_METERS = 5.0; private const val EARTH_RADIUS = TrackMath.EARTH_RADIUS_METERS }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE points (_id INTEGER PRIMARY KEY AUTOINCREMENT, lat REAL NOT NULL, lon REAL NOT NULL, accuracy REAL NOT NULL, time INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX points_time ON points(time)")
        db.execSQL("CREATE INDEX points_lat_lon ON points(lat, lon)")
        db.execSQL("CREATE TABLE explored_cells (cell_x INTEGER NOT NULL, cell_y INTEGER NOT NULL, PRIMARY KEY(cell_x, cell_y))")
        db.execSQL("CREATE INDEX explored_cells_y_x ON explored_cells(cell_y, cell_x)")
        createStatsTable(db)
        ensureStatsAreaColumn(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("CREATE TABLE IF NOT EXISTS explored_cells (cell_x INTEGER NOT NULL, cell_y INTEGER NOT NULL, PRIMARY KEY(cell_x, cell_y))")
        if (oldVersion < 3) db.execSQL("CREATE INDEX IF NOT EXISTS explored_cells_y_x ON explored_cells(cell_y, cell_x)")
        db.execSQL("CREATE INDEX IF NOT EXISTS points_lat_lon ON points(lat, lon)")
        if (oldVersion < 4) createStatsTable(db)
        if (oldVersion < 5) ensureStatsAreaColumn(db)
    }

    /** Insert a GPS fix and update the persisted distance aggregate in one transaction. */
    @Synchronized fun add(point: TrackPoint) {
        require(TrackMath.isValidFix(point.lat, point.lon, point.accuracy, point.time))
        val db = writableDatabase
        db.beginTransaction()
        try {
            insertPointAndUpdateStats(db, point)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** Atomically persist a GPS fix and reveal its surrounding cells. */
    @Synchronized fun recordAndReveal(point: TrackPoint, radiusMeters: Double = 10.0) {
        require(TrackMath.isValidFix(point.lat, point.lon, point.accuracy, point.time))
        require(radiusMeters > 0.0 && radiusMeters <= 1_000.0 && radiusMeters.isFinite())
        val db = writableDatabase
        db.beginTransaction()
        try {
            insertPointAndUpdateStats(db, point)
            insertRevealCells(db, point, radiusMeters)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    private fun insertPointAndUpdateStats(db: SQLiteDatabase, point: TrackPoint) {
        ensureDistanceStatsInitialized(db)
        val previous = readLastPoint(db)
        val currentDistance = readStoredDistance(db)
        val isNewestFix = previous == null || point.time >= previous.time
        val segment = if (isNewestFix) previous?.let { validSegmentDistance(it, point) } ?: 0.0 else 0.0
        val latest = if (isNewestFix) point else previous
        db.execSQL(
            "INSERT INTO points(lat, lon, accuracy, time) VALUES(?,?,?,?)",
            arrayOf(point.lat, point.lon, point.accuracy, point.time)
        )
        db.execSQL(
            "UPDATE app_stats SET distance_meters = ?, last_lat = ?, last_lon = ?, last_accuracy = ?, last_time = ? WHERE _id = 1",
            arrayOf(currentDistance + segment, latest?.lat, latest?.lon, latest?.accuracy?.toDouble(), latest?.time)
        )
    }

    private fun createStatsTable(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS app_stats (_id INTEGER PRIMARY KEY CHECK(_id = 1), distance_meters REAL, last_lat REAL, last_lon REAL, last_accuracy REAL, last_time INTEGER, explored_area_m2 REAL)")
        db.execSQL("INSERT OR IGNORE INTO app_stats(_id, distance_meters, explored_area_m2) VALUES(1, NULL, NULL)")
    }

    /** Add the aggregate column to databases created by earlier app versions. */
    private fun ensureStatsAreaColumn(db: SQLiteDatabase) {
        val exists = db.rawQuery("PRAGMA table_info(app_stats)", null).use { cursor ->
            var found = false
            while (cursor.moveToNext()) if (cursor.getString(1) == "explored_area_m2") found = true
            found
        }
        if (!exists) db.execSQL("ALTER TABLE app_stats ADD COLUMN explored_area_m2 REAL")
    }

    /** Calculate legacy explored area once, then maintain it incrementally. */
    private fun ensureExploredAreaStatsInitialized(db: SQLiteDatabase) {
        val initialized = db.rawQuery("SELECT explored_area_m2 FROM app_stats WHERE _id = 1", null).use {
            it.moveToFirst() && !it.isNull(0)
        }
        if (initialized) return

        var total = 0.0
        db.rawQuery("SELECT cell_y, COUNT(*) FROM explored_cells GROUP BY cell_y", null).use { cursor ->
            while (cursor.moveToNext()) {
                total += cursor.getLong(1) * TrackMath.exploredCellAreaSquareMeters(cursor.getInt(0), CELL_METERS)
            }
        }
        db.execSQL("UPDATE app_stats SET explored_area_m2 = ? WHERE _id = 1", arrayOf(total))
    }

    /** Backfill old installations once; subsequent distance reads are a single-row lookup. */
    private fun ensureDistanceStatsInitialized(db: SQLiteDatabase) {
        val initialized = db.rawQuery("SELECT distance_meters FROM app_stats WHERE _id = 1", null).use {
            it.moveToFirst() && !it.isNull(0)
        }
        if (initialized) return

        val points = queryWithDatabase(db, "SELECT lat, lon, accuracy, time FROM points ORDER BY time, _id", null)
        var total = 0.0
        for (i in 1 until points.size) total += validSegmentDistance(points[i - 1], points[i])
        val last = points.lastOrNull()
        db.execSQL(
            "UPDATE app_stats SET distance_meters = ?, last_lat = ?, last_lon = ?, last_accuracy = ?, last_time = ? WHERE _id = 1",
            arrayOf(total, last?.lat, last?.lon, last?.accuracy?.toDouble(), last?.time)
        )
    }

    private fun readStoredDistance(db: SQLiteDatabase): Double = db.rawQuery(
        "SELECT distance_meters FROM app_stats WHERE _id = 1", null
    ).use { if (it.moveToFirst() && !it.isNull(0)) it.getDouble(0) else 0.0 }

    private fun readLastPoint(db: SQLiteDatabase): TrackPoint? = db.rawQuery(
        "SELECT last_lat, last_lon, last_accuracy, last_time FROM app_stats WHERE _id = 1 AND last_lat IS NOT NULL", null
    ).use { c ->
        if (c.moveToFirst()) TrackPoint(c.getDouble(0), c.getDouble(1), c.getFloat(2), c.getLong(3)) else null
    }

    private fun queryWithDatabase(db: SQLiteDatabase, sql: String, args: Array<String>?): List<TrackPoint> {
        val result = mutableListOf<TrackPoint>()
        db.rawQuery(sql, args).use { c ->
            while (c.moveToNext()) result.add(TrackPoint(c.getDouble(0), c.getDouble(1), c.getFloat(2), c.getLong(3)))
        }
        return result
    }

    private fun validSegmentDistance(a: TrackPoint, b: TrackPoint): Double =
        TrackMath.validSegmentDistanceMeters(a, b)

    /** Persist the union of 5 m cells intersecting the approximately 10 m reveal radius. */
    @Synchronized fun revealAround(point: TrackPoint, radiusMeters: Double = 10.0) {
        require(TrackMath.isValidFix(point.lat, point.lon, point.accuracy, point.time))
        require(radiusMeters > 0.0 && radiusMeters <= 1_000.0 && radiusMeters.isFinite())
        val db = writableDatabase
        db.beginTransaction()
        try {
            insertRevealCells(db, point, radiusMeters)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    private fun insertRevealCells(db: SQLiteDatabase, point: TrackPoint, radiusMeters: Double) {
        ensureExploredAreaStatsInitialized(db)
        val latRad = Math.toRadians(point.lat)
        val centerX = (EARTH_RADIUS * Math.toRadians(point.lon) / CELL_METERS).roundToInt()
        val centerY = (EARTH_RADIUS * latRad / CELL_METERS).roundToInt()
        val cosLat = cos(latRad).coerceAtLeast(0.05)
        val xRange = ceil(radiusMeters / (CELL_METERS * cosLat)).toInt() + 1
        val yRange = ceil(radiusMeters / CELL_METERS).toInt() + 1
        val expanded = radiusMeters + CELL_METERS * 0.71
        val insertCell: SQLiteStatement = db.compileStatement(
            "INSERT OR IGNORE INTO explored_cells(cell_x, cell_y) VALUES(?,?)"
        )
        var newlyExploredArea = 0.0
        try {
            for (dy in -yRange..yRange) for (dx in -xRange..xRange) {
                val east = dx * CELL_METERS * cosLat
                val north = dy * CELL_METERS
                if (east * east + north * north <= expanded * expanded) {
                    val cellY = centerY + dy
                    insertCell.bindLong(1, (centerX + dx).toLong())
                    insertCell.bindLong(2, cellY.toLong())
                    // SQLite returns -1 for INSERT OR IGNORE when this cell already exists.
                    if (insertCell.executeInsert() != -1L) {
                        newlyExploredArea += TrackMath.exploredCellAreaSquareMeters(cellY, CELL_METERS)
                    }
                    insertCell.clearBindings()
                }
            }
        } finally {
            insertCell.close()
        }
        if (newlyExploredArea > 0.0) {
            db.execSQL(
                "UPDATE app_stats SET explored_area_m2 = explored_area_m2 + ? WHERE _id = 1",
                arrayOf(newlyExploredArea)
            )
        }
    }

    /** Fetch viewport cells, coalescing fine 5 m cells into larger display cells at low zoom. */
    @Synchronized fun visibleCells(
        north: Double, east: Double, south: Double, west: Double,
        limit: Int = 25000, aggregationFactor: Int = 1
    ): List<ExploredCell> {
        val safeLimit = limit.coerceIn(1, 25000)
        var factor = aggregationFactor.coerceIn(1, TrackMath.MAX_FOG_AGGREGATION_FACTOR)
        val n = north.coerceIn(-90.0, 90.0); val s = south.coerceIn(-90.0, 90.0)
        val yMin = floor(EARTH_RADIUS * Math.toRadians(min(s, n)) / CELL_METERS).toInt() - 2
        val yMax = ceil(EARTH_RADIUS * Math.toRadians(max(s, n)) / CELL_METERS).toInt() + 2
        // Cell indices are stored with roundToInt() around cell centers. Expand the
        // viewport bounds before querying so cells touching an edge are not omitted.
        fun xLower(lon: Double) = floor(EARTH_RADIUS * Math.toRadians(lon) / CELL_METERS).toInt() - 2
        fun xUpper(lon: Double) = ceil(EARTH_RADIUS * Math.toRadians(lon) / CELL_METERS).toInt() + 2
        val westX = xLower(west)
        val eastX = xUpper(east)
        val wrapsDateLine = west > east

        // Fetch one extra row to detect truncation. If the requested zoom still
        // produces too many groups, coarsen the grid and retry instead of silently
        // showing only the first (north-western) 25,000 cells.
        while (true) {
            val gx = "((cell_x - ((cell_x % $factor + $factor) % $factor)) / $factor)"
            val gy = "((cell_y - ((cell_y % $factor + $factor) % $factor)) / $factor)"
            val sql = if (!wrapsDateLine) {
                "SELECT $gx, $gy FROM explored_cells WHERE cell_y BETWEEN ? AND ? AND cell_x BETWEEN ? AND ? GROUP BY $gx, $gy ORDER BY $gy, $gx LIMIT ?"
            } else {
                "SELECT $gx, $gy FROM explored_cells WHERE cell_y BETWEEN ? AND ? AND (cell_x >= ? OR cell_x <= ?) GROUP BY $gx, $gy ORDER BY $gy, $gx LIMIT ?"
            }
            val result = ArrayList<ExploredCell>(safeLimit + 1)
            readableDatabase.rawQuery(
                sql,
                arrayOf(yMin.toString(), yMax.toString(), westX.toString(), eastX.toString(), (safeLimit + 1).toString())
            ).use { c ->
                while (c.moveToNext()) {
                    val centerX = c.getInt(0) * factor + (factor - 1) / 2.0
                    val centerY = c.getInt(1) * factor + (factor - 1) / 2.0
                    result.add(ExploredCell(centerX, centerY, factor))
                }
            }
            if (result.size <= safeLimit || factor >= TrackMath.MAX_FOG_AGGREGATION_FACTOR) {
                return if (result.size > safeLimit) result.take(safeLimit) else result
            }
            factor = TrackMath.nextFogAggregationFactor(factor)
        }
    }

    @Synchronized fun exploredCellCount(): Long = readableDatabase.rawQuery("SELECT COUNT(*) FROM explored_cells", null).use { if (it.moveToFirst()) it.getLong(0) else 0L }

    /**
     * Sum row-weighted ground areas. The stored grid is equirectangular, so a
     * 5 m x 5 m projected cell has ground area 25 * cos(latitude) m².
     */
    @Synchronized fun exploredAreaSquareMeters(): Double {
        val db = writableDatabase
        db.beginTransaction()
        try {
            ensureExploredAreaStatsInitialized(db)
            val total = db.rawQuery(
                "SELECT explored_area_m2 FROM app_stats WHERE _id = 1", null
            ).use { if (it.moveToFirst() && !it.isNull(0)) it.getDouble(0) else 0.0 }
            db.setTransactionSuccessful()
            return total
        } finally { db.endTransaction() }
    }
    /** Read only the newest persisted fix; never load the full history during app startup. */
    @Synchronized fun lastPoint(): TrackPoint? = readableDatabase.rawQuery(
        "SELECT lat, lon, accuracy, time FROM points ORDER BY time DESC, _id DESC LIMIT 1", null
    ).use { c ->
        if (c.moveToFirst()) TrackPoint(c.getDouble(0), c.getDouble(1), c.getFloat(2), c.getLong(3)) else null
    }

    /** Count fixes in the viewport in SQLite without materializing every GPS row. */
    @Synchronized fun visibleCount(north: Double, east: Double, south: Double, west: Double): Int {
        val latPad = 0.002
        val n = (max(north, south) + latPad).coerceAtMost(90.0)
        val s = (min(north, south) - latPad).coerceAtLeast(-90.0)
        val e = (east + 0.002).coerceAtMost(180.0)
        val w = (west - 0.002).coerceAtLeast(-180.0)
        val sql = if (west <= east) {
            "SELECT COUNT(*) FROM points WHERE lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?"
        } else {
            "SELECT COUNT(*) FROM points WHERE lat BETWEEN ? AND ? AND (lon >= ? OR lon <= ?)"
        }
        return readableDatabase.rawQuery(sql, arrayOf(s.toString(), n.toString(), w.toString(), e.toString())).use {
            if (it.moveToFirst()) it.getInt(0) else 0
        }
    }

    @Synchronized fun visible(north: Double, east: Double, south: Double, west: Double): List<TrackPoint> {
        val latPad = 0.002; val lonPad = 0.002
        val n = (north + latPad).coerceAtMost(90.0); val s = (south - latPad).coerceAtLeast(-90.0)
        val e = (east + lonPad).coerceAtMost(180.0); val w = (west - lonPad).coerceAtLeast(-180.0)
        return if (west <= east) query("SELECT lat, lon, accuracy, time FROM points WHERE lat BETWEEN ? AND ? AND lon BETWEEN ? AND ? ORDER BY time", arrayOf(s.toString(), n.toString(), w.toString(), e.toString()))
        else query("SELECT lat, lon, accuracy, time FROM points WHERE lat BETWEEN ? AND ? AND (lon >= ? OR lon <= ?) ORDER BY time", arrayOf(s.toString(), n.toString(), w.toString(), e.toString()))
    }

    private fun query(sql: String, args: Array<String>?): List<TrackPoint> {
        val result = mutableListOf<TrackPoint>()
        readableDatabase.rawQuery(sql, args).use { c -> while (c.moveToNext()) result.add(TrackPoint(c.getDouble(0), c.getDouble(1), c.getFloat(2), c.getLong(3))) }
        return result
    }
    @Synchronized fun count(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM points", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }

    @Synchronized fun distanceMeters(): Double {
        val current = readableDatabase.rawQuery(
            "SELECT distance_meters FROM app_stats WHERE _id = 1", null
        ).use { if (it.moveToFirst() && !it.isNull(0)) it.getDouble(0) else null }
        if (current != null) return current

        val db = writableDatabase
        db.beginTransaction()
        try {
            ensureDistanceStatsInitialized(db)
            val distance = readStoredDistance(db)
            db.setTransactionSuccessful()
            return distance
        } finally { db.endTransaction() }
    }
    private fun haversine(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double =
        TrackMath.haversineMeters(lat1, lon1, lat2, lon2)
}
