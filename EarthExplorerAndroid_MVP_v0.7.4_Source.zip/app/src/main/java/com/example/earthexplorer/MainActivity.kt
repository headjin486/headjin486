package com.example.earthexplorer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : Activity() {
    private lateinit var map: MapView
    private lateinit var fog: FogOverlay
    private lateinit var countText: TextView
    private lateinit var currentMarker: Marker
    private val storeDelegate = lazy { TrackStore(this) }
    private val store by storeDelegate
    private val requestCode = 100
    private var receiverRegistered = false
    private var centeredOnLiveFix = false
    private val refreshExecutor = Executors.newSingleThreadExecutor()
    private val refreshGeneration = AtomicInteger(0)
    private val activityShuttingDown = AtomicBoolean(false)

    private val trackingReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshFog()
            val lat = intent?.getDoubleExtra(LocationTrackingService.EXTRA_LAT, Double.NaN) ?: Double.NaN
            val lon = intent?.getDoubleExtra(LocationTrackingService.EXTRA_LON, Double.NaN) ?: Double.NaN
            if (!lat.isNaN() && !lon.isNaN()) { updateCurrentPosition(GeoPoint(lat, lon), !centeredOnLiveFix); centeredOnLiveFix = true }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        Configuration.getInstance().userAgentValue = "EarthExplorer/0.7.4 (Android; $packageName)"
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(7, 23, 45)) }
        val header = TextView(this).apply { text = "🌍  지구 탐험"; textSize = 23f; setTextColor(Color.WHITE); setPadding(20, 18, 20, 12) }
        root.addView(header)
        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK); setMultiTouchControls(true)
            controller.setZoom(4.0); controller.setCenter(GeoPoint(36.5, 127.8))
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        root.addView(map)
        val attribution = TextView(this).apply {
            text = "© OpenStreetMap contributors · ODbL"
            textSize = 11f
            setTextColor(Color.DKGRAY)
            setPadding(8, 3, 8, 3)
            setBackgroundColor(Color.WHITE)
            contentDescription = "OpenStreetMap 저작자 표시 및 라이선스 안내 열기"
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.openstreetmap.org/copyright")))
            }
        }
        root.addView(attribution)
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 12, 18, 18); setBackgroundColor(Color.rgb(10, 31, 58)) }
        countText = TextView(this).apply { textSize = 15f; setTextColor(Color.WHITE) }
        panel.addView(countText)
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val start = Button(this).apply { text = "자동 탐험 시작"; setOnClickListener { requestAndStart() } }
        val stop = Button(this).apply { text = "탐험 중지"; setOnClickListener { stopService(Intent(this@MainActivity, LocationTrackingService::class.java)); refreshFog() } }
        row1.addView(start, LinearLayout.LayoutParams(0, -2, 1f)); row1.addView(stop, LinearLayout.LayoutParams(0, -2, 1f))
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val refresh = Button(this).apply { text = "지도 갱신"; setOnClickListener { refreshFog() } }
        val settings = Button(this).apply { text = "위치 권한 설정"; setOnClickListener { openAppSettings() } }
        row2.addView(refresh, LinearLayout.LayoutParams(0, -2, 1f)); row2.addView(settings, LinearLayout.LayoutParams(0, -2, 1f))
        val privacy = Button(this).apply {
            text = "개인정보 처리방침"
            setOnClickListener { startActivity(Intent(this@MainActivity, PrivacyPolicyActivity::class.java)) }
        }
        panel.addView(row1); panel.addView(row2); panel.addView(privacy); root.addView(panel); setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)
        fog = FogOverlay(map, emptyList())
        currentMarker = Marker(map).apply { title = "현재 위치"; setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM) }
        map.overlays.add(fog); map.overlays.add(currentMarker)
        map.addMapListener(object : MapListener {
            override fun onScroll(event: ScrollEvent?): Boolean { fog.invalidateViewport(); refreshFog(); return true }
            override fun onZoom(event: ZoomEvent?): Boolean { fog.invalidateViewport(); refreshFog(); return true }
        })
        store.lastPoint()?.let { last ->
            val point = GeoPoint(last.lat, last.lon)
            updateCurrentPosition(point, true)
            centeredOnLiveFix = true
        }
        refreshFog()
    }

    private fun requestAndStart() {
        // Location tracking is started only from this visible, user-initiated screen.
        // A location foreground service can continue after the app is minimized;
        // ACCESS_BACKGROUND_LOCATION is not requested by this MVP.
        val fineGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (fineGranted) {
            showLocationDisclosureAndStart()
            return
        }

        val permissions = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        ActivityCompat.requestPermissions(this, permissions, requestCode)
    }

    private fun showLocationDisclosureAndStart() {
        AlertDialog.Builder(this)
            .setTitle("위치 정보 사용 안내")
            .setMessage(
                "자동 탐험을 켜면 이동 중 GPS 위치를 수집해 현재 위치를 표시하고, 지나간 주변을 지도에 공개합니다. " +
                    "위치와 탐험 기록은 이 기기의 앱 내부 데이터베이스에 저장됩니다. " +
                    "앱을 다른 화면으로 전환해도 사용자가 중지할 때까지 위치 기록이 계속되며, 시스템 포그라운드 서비스 알림이 표시됩니다. Android 13 이상에서 알림 권한을 거부한 경우 알림 창에는 보이지 않고 시스템 작업 관리자에 표시될 수 있습니다. " +
                    "지도 타일을 불러오기 위해 지도 제공자에 지도 영역 요청이 전송될 수 있습니다. " +
                    "현재 MVP는 계정 동기화 기능을 제공하지 않습니다."
            )
            .setNegativeButton("취소", null)
            .setPositiveButton("동의하고 시작") { _, _ ->
                try {
                    ContextCompat.startForegroundService(
                        this,
                        Intent(this, LocationTrackingService::class.java)
                    )
                    countText.text = "자동 탐험을 시작했습니다. 알림에서 추적 상태를 확인할 수 있습니다."
                } catch (e: Exception) {
                    countText.text = "탐험을 시작하지 못했습니다. 위치 권한과 기기 설정을 확인하세요."
                }
            }
            .show()
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply { data = Uri.fromParts("package", packageName, null) })
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != this.requestCode) return
        val fineGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (fineGranted) {
            showLocationDisclosureAndStart()
        } else {
            AlertDialog.Builder(this)
                .setTitle("정확한 위치 권한이 필요합니다")
                .setMessage("약 10m 범위의 탐험 지도를 만들려면 정확한 위치 권한이 필요합니다. 설정에서 위치 권한을 '정확한 위치'로 허용한 뒤 다시 시작해 주세요.")
                .setPositiveButton("앱 설정 열기") { _, _ -> openAppSettings() }
                .setNegativeButton("닫기", null)
                .show()
        }
    }

    private fun refreshFog() {
        if (!::map.isInitialized || !::fog.isInitialized || activityShuttingDown.get() || isFinishing || isDestroyed) return
        val bounds = map.boundingBox
        val north = bounds.latNorth
        val east = bounds.lonEast
        val south = bounds.latSouth
        val west = bounds.lonWest
        val zoom = map.zoomLevelDouble
        val generation = refreshGeneration.incrementAndGet()

        // SQLite range scans and large cell lists must not run on the UI thread.
        // Obsolete pan/zoom requests are discarded before doing database work.
        try {
            refreshExecutor.execute {
                if (generation != refreshGeneration.get() || activityShuttingDown.get()) return@execute
                try {
                    val visibleGpsCount = store.visibleCount(north, east, south, west)
                    val aggregationFactor = TrackMath.fogAggregationFactor(zoom)
                    val visibleCells = store.visibleCells(
                        north, east, south, west, limit = 25000,
                        aggregationFactor = aggregationFactor
                    )
                    val distance = store.distanceMeters()
                    val area = store.exploredAreaSquareMeters()
                    val totalPoints = store.count()
                    val totalCells = store.exploredCellCount()

                    runOnUiThread {
                        if (generation != refreshGeneration.get() || activityShuttingDown.get() || isFinishing || isDestroyed) return@runOnUiThread
                        fog.update(visibleCells)
                        val distanceLabel = if (distance >= 1000)
                            String.format(Locale.getDefault(), "%.2f km", distance / 1000)
                        else String.format(Locale.getDefault(), "%.0f m", distance)
                        val areaLabel = if (area >= 1_000_000.0)
                            String.format(Locale.getDefault(), "%.3f km²", area / 1_000_000.0)
                        else String.format(Locale.getDefault(), "%.0f m²", area)
                        countText.text = "저장된 GPS 기록 ${totalPoints}개 · 누적 이동 거리(추정) $distanceLabel\n" +
                            "누적 공개 면적(격자 추정) $areaLabel · 공개 셀 ${totalCells}개\n" +
                            "현재 화면 GPS ${visibleGpsCount}개 · 현재 화면 공개 격자 ${visibleCells.size}개\n" +
                            "※ 지도 축척별 공개 격자 집계 표시 · 집계 배율 ${aggregationFactor}x · 육지 면적·세계 탐험률은 아직 미구현입니다."
                    }
                } catch (_: Exception) {
                    runOnUiThread {
                        if (generation == refreshGeneration.get() && !activityShuttingDown.get() && !isFinishing && !isDestroyed) {
                            countText.text = "지도 데이터를 불러오지 못했습니다. 잠시 후 다시 시도해 주세요."
                        }
                    }
                }
            }
        } catch (_: RejectedExecutionException) {
            // A map callback can race Activity teardown; its refresh is no longer needed.
        }
    }

    private fun updateCurrentPosition(point: GeoPoint, center: Boolean) {
        currentMarker.position = point
        if (!map.overlays.contains(currentMarker)) map.overlays.add(currentMarker)
        if (center) map.controller.animateTo(point)
        map.invalidate()
    }

    override fun onStart() {
        super.onStart()
        if (!receiverRegistered) {
            ContextCompat.registerReceiver(this, trackingReceiver, IntentFilter(LocationTrackingService.ACTION_TRACK_UPDATED), ContextCompat.RECEIVER_NOT_EXPORTED)
            receiverRegistered = true
        }
        refreshFog()
    }
    override fun onStop() { if (receiverRegistered) { unregisterReceiver(trackingReceiver); receiverRegistered = false }; super.onStop() }
    override fun onResume() { super.onResume(); if (::map.isInitialized) map.onResume(); refreshFog() }
    override fun onPause() { if (::map.isInitialized) map.onPause(); super.onPause() }
    override fun onDestroy() {
        activityShuttingDown.set(true)
        // Invalidate pending UI callbacks, then let the single-thread executor finish
        // any SQLite read already in progress before closing this Activity's helper.
        refreshGeneration.incrementAndGet()
        if (storeDelegate.isInitialized()) {
            refreshExecutor.execute { store.close() }
        }
        refreshExecutor.shutdown()
        if (::fog.isInitialized) fog.release()
        if (::map.isInitialized) map.onDetach()
        super.onDestroy()
    }
}
