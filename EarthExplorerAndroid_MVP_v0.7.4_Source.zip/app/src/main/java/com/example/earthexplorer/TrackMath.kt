package com.example.earthexplorer

import kotlin.math.*

/** Pure calculations shared by persistence and unit tests. */
internal object TrackMath {
    const val EARTH_RADIUS_METERS = 6_371_000.0
    const val MAX_FOG_AGGREGATION_FACTOR = 1 shl 20

    fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        require(lat1 in -90.0..90.0 && lat2 in -90.0..90.0)
        require(lon1 in -180.0..180.0 && lon2 in -180.0..180.0)
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2.0) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2.0)
        return 2.0 * EARTH_RADIUS_METERS * asin(sqrt(a.coerceIn(0.0, 1.0)))
    }

    /** Choose a power-of-two aggregation factor for readable, bounded fog rendering. */
    fun fogAggregationFactor(zoom: Double): Int = when {
        zoom >= 18.0 -> 1
        zoom >= 16.0 -> 4
        zoom >= 14.0 -> 16
        zoom >= 12.0 -> 64
        zoom >= 10.0 -> 256
        zoom >= 8.0 -> 1_024
        zoom >= 6.0 -> 4_096
        zoom >= 4.0 -> 16_384
        else -> 65_536
    }

    /** Increase the grouping scale when a viewport would otherwise be truncated. */
    fun nextFogAggregationFactor(current: Int): Int {
        val safe = current.coerceIn(1, MAX_FOG_AGGREGATION_FACTOR)
        return (safe * 2).coerceAtMost(MAX_FOG_AGGREGATION_FACTOR)
    }

    /** Convert the stored equirectangular grid X coordinate back to longitude.
     * TrackStore creates X as R * longitudeRadians / cellSize, so this inverse
     * must not apply another latitude correction. Latitude correction belongs
     * only in ground-distance calculations (for example reveal-radius bounds).
     */
    fun gridLongitudeDegrees(cellX: Double, cellSizeMeters: Double): Double {
        require(cellX.isFinite())
        require(cellSizeMeters > 0.0 && cellSizeMeters.isFinite())
        return Math.toDegrees(cellX * cellSizeMeters / EARTH_RADIUS_METERS)
    }

    /** Convert an equirectangular grid Y coordinate to latitude. */
    fun gridLatitudeDegrees(cellY: Double, cellSizeMeters: Double): Double {
        require(cellSizeMeters > 0.0 && cellSizeMeters.isFinite())
        return Math.toDegrees(cellY * cellSizeMeters / EARTH_RADIUS_METERS).coerceIn(-90.0, 90.0)
    }

    /**
     * Ground area of one cell in the equirectangular 5 m grid.
     * The north/south side remains cellSizeMeters, while the east/west side
     * shrinks by cos(latitude). cellY is the rounded grid-center index.
     */
    fun exploredCellAreaSquareMeters(cellY: Int, cellSizeMeters: Double): Double {
        require(cellSizeMeters > 0.0 && cellSizeMeters.isFinite())
        val latitudeRadians = (cellY.toDouble() * cellSizeMeters / EARTH_RADIUS_METERS)
            .coerceIn(-Math.PI / 2.0, Math.PI / 2.0)
        return cellSizeMeters * cellSizeMeters * cos(latitudeRadians).coerceAtLeast(0.0)
    }

    /** Reject malformed fixes before they can enter the persistent GPS history or fog grid. */
    fun isValidFix(lat: Double, lon: Double, accuracyMeters: Float, timeMillis: Long): Boolean =
        lat.isFinite() && lon.isFinite() &&
            lat in -90.0..90.0 && lon in -180.0..180.0 &&
            accuracyMeters.isFinite() && accuracyMeters >= 0f && accuracyMeters <= 20f &&
            timeMillis > 0L

    /** Only strictly newer timestamps may advance the live tracking baseline. */
    fun isNewerFix(previousTimeMillis: Long, currentTimeMillis: Long): Boolean =
        currentTimeMillis > previousTimeMillis && currentTimeMillis > 0L

    /** Reject time reversals, long gaps, teleport-sized jumps and impossible speeds. */
    fun validSegmentDistanceMeters(a: TrackPoint, b: TrackPoint): Double {
        val elapsedMs = b.time - a.time
        if (elapsedMs !in 1L..120_000L) return 0.0
        val distance = haversineMeters(a.lat, a.lon, b.lat, b.lon)
        val speedMetersPerSecond = distance / (elapsedMs / 1_000.0)
        return if (distance <= 1_500.0 && speedMetersPerSecond <= 45.0) distance else 0.0
    }
}
