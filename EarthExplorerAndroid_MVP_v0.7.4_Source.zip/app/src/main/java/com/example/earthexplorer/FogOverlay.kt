package com.example.earthexplorer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Point
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay

/** Fog is cleared exclusively from durable SQLite explored_cells data.
 * The viewport mask is rasterized once and reused until the map viewport/data changes.
 */
class FogOverlay(private val map: MapView, private var cells: List<ExploredCell>) : Overlay() {
    private val fogPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(244, 5, 13, 29)
        style = Paint.Style.FILL
    }
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.TRANSPARENT
        style = Paint.Style.FILL
        xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR)
    }
    private var cachedMask: Bitmap? = null

    /** Called after a pan/zoom or a change to the visible SQLite cell set. */
    fun update(newCells: List<ExploredCell>) {
        if (cells == newCells) return
        cells = newCells
        clearCache()
        map.invalidate()
    }

    private fun clearCache() {
        cachedMask?.takeUnless { it.isRecycled }?.recycle()
        cachedMask = null
    }

    fun release() = clearCache()

    /** A pan/zoom changes the projection even when the queried cell IDs are unchanged. */
    fun invalidateViewport() {
        clearCache()
        map.invalidate()
    }

    override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
        if (shadow) return
        val width = canvas.width
        val height = canvas.height
        if (width <= 0 || height <= 0) return

        var mask = cachedMask
        if (mask == null || mask.isRecycled || mask.width != width || mask.height != height) {
            clearCache()
            mask = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            renderMask(mask, mapView)
            cachedMask = mask
        }
        canvas.drawBitmap(mask, 0f, 0f, bitmapPaint)
    }

    private fun renderMask(bitmap: Bitmap, mapView: MapView) {
        val maskCanvas = Canvas(bitmap)
        maskCanvas.drawColor(Color.TRANSPARENT, android.graphics.PorterDuff.Mode.CLEAR)
        maskCanvas.drawRect(0f, 0f, bitmap.width.toFloat(), bitmap.height.toFloat(), fogPaint)

        val projection = mapView.projection
        val cell = TrackStore.CELL_METERS
        val p1 = Point(); val p2 = Point(); val p3 = Point(); val p4 = Point()
        val path = Path()
        for (item in cells) {
            // Coordinates are aggregated cell centers; scale expands the rendered cell.
            val displayCell = cell * item.scale
            val south = TrackMath.gridLatitudeDegrees(item.y - item.scale / 2.0, cell)
            val north = TrackMath.gridLatitudeDegrees(item.y + item.scale / 2.0, cell)
            val west = TrackMath.gridLongitudeDegrees(item.x - item.scale / 2.0, cell)
            val east = TrackMath.gridLongitudeDegrees(item.x + item.scale / 2.0, cell)
            projection.toPixels(GeoPoint(north, west), p1)
            projection.toPixels(GeoPoint(north, east), p2)
            projection.toPixels(GeoPoint(south, east), p3)
            projection.toPixels(GeoPoint(south, west), p4)
            path.reset()
            path.moveTo(p1.x.toFloat(), p1.y.toFloat())
            path.lineTo(p2.x.toFloat(), p2.y.toFloat())
            path.lineTo(p3.x.toFloat(), p3.y.toFloat())
            path.lineTo(p4.x.toFloat(), p4.y.toFloat())
            path.close()
            maskCanvas.drawPath(path, clearPaint)
        }
    }
}
