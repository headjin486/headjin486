package com.example.earthexplorer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.google.android.gms.location.*
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicBoolean

class LocationTrackingService : Service() {
    companion object {
        const val ACTION_TRACK_UPDATED = "com.example.earthexplorer.TRACK_UPDATED"
        const val EXTRA_LAT = "latitude"
        const val EXTRA_LON = "longitude"
        const val ACTION_STOP = "com.example.earthexplorer.STOP_TRACKING"
    }
    private lateinit var fused: FusedLocationProviderClient
    private lateinit var callback: LocationCallback
    private lateinit var store: TrackStore
    // SQLite writes and reveal-cell generation are serialized away from the main thread.
    private val persistenceExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "earth-unlock-location-db").apply { isDaemon = true }
    }
    private var lastSaved: android.location.Location? = null
    // Prevent late fused-location callbacks from enqueueing writes after DB close is queued.
    private val stopping = AtomicBoolean(false)

    override fun onCreate() {
        super.onCreate()
        store = TrackStore(this)
        fused = LocationServices.getFusedLocationProviderClient(this)
        // Seed the de-duplication point before any newly received fixes are processed.
        persistenceExecutor.execute {
            store.lastPoint()?.let { saved ->
                lastSaved = android.location.Location("earth-unlock-db").apply {
                    latitude = saved.lat
                    longitude = saved.lon
                    accuracy = saved.accuracy
                    time = saved.time
                }
            }
        }
        createChannel()
        val notification = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(41, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
            } else {
                startForeground(41, notification)
            }
        } catch (_: SecurityException) {
            // Android 14+ can reject a location FGS if its runtime permission was
            // revoked between the Activity check and service startup.
            stopping.set(true)
            stopSelf()
            return
        } catch (_: IllegalStateException) {
            // Covers platform FGS-start restrictions; never continue as a hidden tracker.
            stopping.set(true)
            stopSelf()
            return
        }

        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000L)
            .setMinUpdateIntervalMillis(3000L)
            .setMinUpdateDistanceMeters(3f)
            .build()

        callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                if (stopping.get()) return
                result.locations.forEach { loc ->
                    if (stopping.get()) return@forEach
                    // Ignore weak fixes; a 10 m reveal is not credible when GPS error is large.
                    if (!loc.hasAccuracy() || !TrackMath.isValidFix(
                            loc.latitude, loc.longitude, loc.accuracy, loc.time
                        )) return@forEach
                    // Keep ordering deterministic: the previous accepted fix is read and
                    // updated only on this executor, never on the main location callback.
                    try {
                        persistenceExecutor.execute {
                            // This fix was accepted before shutdown; drain it before closing SQLite.
                            val previous = lastSaved
                            // Ignore delayed/out-of-order fixes so they cannot move the
                            // duplicate-filter baseline backwards in time.
                            if (previous != null && !TrackMath.isNewerFix(previous.time, loc.time)) return@execute
                            if (previous != null && previous.distanceTo(loc) < 3f) return@execute
                            val point = TrackPoint(loc.latitude, loc.longitude, loc.accuracy, loc.time)
                            try {
                                // GPS history and fog cells commit together or not at all.
                                store.recordAndReveal(point, 10.0)
                                lastSaved = loc
                                sendBroadcast(Intent(ACTION_TRACK_UPDATED).setPackage(packageName).apply {
                                    putExtra(EXTRA_LAT, loc.latitude)
                                    putExtra(EXTRA_LON, loc.longitude)
                                })
                            } catch (_: Exception) {
                                // A single persistence failure must not crash the location service.
                            }
                        }
                    } catch (_: RejectedExecutionException) {
                        // The service is shutting down; ignore late callbacks.
                    }
                }
            }
        }
        try {
            fused.requestLocationUpdates(request, callback, mainLooper)
                .addOnFailureListener {
                    // Permission revocation and provider failures are reported
                    // asynchronously by Play services, not always as a thrown exception.
                    stopping.set(true)
                    stopSelf()
                }
        } catch (_: SecurityException) {
            stopping.set(true)
            stopSelf()
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("tracking", "지구 탐험 위치 기록", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "tracking") else Notification.Builder(this)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, LocationTrackingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return builder.setContentTitle("지구 탐험 기록 중")
            .setContentText("이동 경로 주변을 자동으로 탐험하고 있습니다.")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "탐험 중지", stop).build())
            .setOngoing(true)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // If onCreate could not promote this service to a location foreground
        // service (for example, permission was revoked), do not ask Android to
        // recreate it indefinitely with START_STICKY.
        if (stopping.get() && intent?.action != ACTION_STOP) return START_NOT_STICKY
        if (intent?.action == ACTION_STOP) {
            stopping.set(true)
            if (::fused.isInitialized && ::callback.isInitialized) fused.removeLocationUpdates(callback)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
            return START_NOT_STICKY
        }
        // Recreate the foreground tracker if Android reclaims the process.
        // The system does not restart a service after an explicit stop or force-stop.
        return START_STICKY
    }

    override fun onDestroy() {
        stopping.set(true)
        if (::fused.isInitialized && ::callback.isInitialized) fused.removeLocationUpdates(callback)
        sendBroadcast(Intent(ACTION_TRACK_UPDATED).setPackage(packageName).putExtra("stopped", true))
        // shutdown() drains already accepted fixes in order, then closes SQLite.
        // This executor is owned by the service and is shut down only here. Queue
        // the close behind all accepted writes, then reject any later submissions.
        try {
            persistenceExecutor.execute { store.close() }
        } catch (_: RejectedExecutionException) {
            // The executor has already been shut down; do not close SQLite from
            // this thread because a previously queued operation may still own it.
        }
        persistenceExecutor.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
