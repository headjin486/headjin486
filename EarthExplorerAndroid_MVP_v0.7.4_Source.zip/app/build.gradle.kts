import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
val signingProperties = Properties()
val signingPropertiesFile = rootProject.file("keystore.properties")
if (signingPropertiesFile.exists()) {
    signingPropertiesFile.inputStream().use(signingProperties::load)
}
val releaseStorePath = signingProperties.getProperty("storeFile")
val hasReleaseSigning = !releaseStorePath.isNullOrBlank() &&
    !signingProperties.getProperty("storePassword").isNullOrBlank() &&
    !signingProperties.getProperty("keyAlias").isNullOrBlank() &&
    !signingProperties.getProperty("keyPassword").isNullOrBlank() &&
    rootProject.file(releaseStorePath).isFile

android {
    namespace = "com.example.earthexplorer"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.example.earthexplorer"
        minSdk = 26
        targetSdk = 36
        versionCode = 28
        versionName = "0.7.4"
    }
    signingConfigs {
        create("release") {
            if (hasReleaseSigning) {
                storeFile = rootProject.file(releaseStorePath!!)
                storePassword = signingProperties.getProperty("storePassword")!!
                keyAlias = signingProperties.getProperty("keyAlias")!!
                keyPassword = signingProperties.getProperty("keyPassword")!!
            }
        }
    }
    buildTypes {
        getByName("release") {
            // Release signing is enabled only after the developer supplies a private keystore.
            if (hasReleaseSigning) {
                signingConfig = signingConfigs.getByName("release")
            }
            isMinifyEnabled = false // Enable shrinking only after device/Play internal-track validation.
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("org.osmdroid:osmdroid-android:6.1.20")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("com.google.android.gms:play-services-location:21.3.0")
    testImplementation("junit:junit:4.13.2")
}
